# Input and output file names

names_file = 'sort.txt'

output_file = 'list1.txt'

 

# Read the list of names

with open(names_file, 'r') as f:

    names = [line.strip() for line in f]

 

# Generate numbers from 0000 to 9999

numbers = [f"{i:04}" for i in range(10000)]  # Generates 0000 to 9999

 

# Combine names and numbers without a space

with open(output_file, 'w') as f:

    for name in names:

        for number in numbers:

            f.write(f"{name}{number}\n")

 

print("File has been generated as 'output.txt'")
