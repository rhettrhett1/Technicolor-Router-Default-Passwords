# File name (replace with your file name)
input_file = 'list2.txt'
output_file = 'output.txt'  # You can overwrite input.txt by setting this to 'input.txt'

# Convert text to lowercase
with open(input_file, 'r') as infile:
    lines = infile.readlines()

with open(output_file, 'w') as outfile:
    for line in lines:
        outfile.write(line.lower())

print(f"All text has been converted to lowercase and saved to '{output_file}'.")
